--------------------------------------------------------
-=>Evil Ken Version Duo Release 0.97<=-
--------------------------------------------------------

By Reu, Tenshin and KingTigre and The Dreamslayer
reuy@email.com

Mugen Institute -=> http://www.reubenkee.com
Download the Intro at Mugen Institute!

------------------------=======================>
What's new since version 7.24?

Added slowdown effect after MSSM shin hadouken.
Tweaked super moves.
Tweaked effects



--------------------------------->
*This character features high-rising moves, one must have vertical scrolling stages to experience the full effect.*
*Ensure helper effects are enabled in your mugen.cfg*
This is the Original first and playable Evil Ken in any fighting game. 



What's Featured:
-------------------------------------
The first particle rendered flame surges, sparks, speckles and splash effects!
The very first Special Meta Super Special Moves system!
The very first custom combo mode! Rage burst!
All ken based moves
Tonnes of original super and special moves!
Never seen before edits of Ken, thanks to Kingtigre!
Ability to do OTG combos.
Ability to chain normal attacks!
Ability to chain normal attacks into special moves!
Ability to cancel special moves into super moves!
Ability to Super Cancel super moves into supermoves!
Combo Rating system!
Original intros, win poses and taunt!
Capcom vs SNK charge up!
Capcom vs SNK style superjump!
Capcom vs SNK flame sound, landing sound, hit sounds, block sounds, voice samples!
Street fighter 3 third strike sound effects and voice samples!
Holy crap! Tonnes of comboability! 
12 Palletes!
Special Intros against Ryu, Akuma, Baby Bonnie Hood and Evil Ken!
Kickass Artificial Intelligence!
-------------------------------------

====================================================
<<<EXPLAINATION OF META SUPER SPECIAL MOVES>>>
===================================================
MSSMs can be performed by combining three level one super moves together. Simply put, they happen on your second super cancel. MSSMs also happen with a probablity of 10% whenever you do a super special move. Only Level one Super Special Moves have MSSM versions.


------------------------------------>
Extra Moves:

Air recover: 2 punches or 2 kicks while falling

Ground recover: 2 punches or 2 kicks while near ground.

Ground roll reover: 2 punches or 2 kicks while lying on ground

Taunt: Start button *(Increases defense)*

Normal Jump launch: Jump after Crouching Forward  heavy punch

Super Jump Lanuch: Jump after Crouching heavy punch

Knee Jab: Back + Heavy Kick

Standing Uppercut ( Can be used to continue air juggles): Back + Heavy Punch

Standing Withheld Uppercut: Back + Medium Punch

Slammy Kick: Back + Medium Kick

Hop Kick: Forward + Medium Kick

----------------------------------->

*UPDATED* Alpha counters: Alpha counters are performed when the player does a back to down motion, followed by an attack button. Alpha counters require at least ONE level.

Punch counter: Ken does a flaming shoryuken which sends his opponent flying

Kick counter: Ken performs a roundhouse Tenshou Tatsumaki Senpuu Kyaku

Air Punch counter: Ken does a fierce bakuretsuken

Air Kick coutner: Ken does a roundhouse Kuuchuu Tatsumaki Senpuu Kyaku


----------------------------------->
Special moves:

Jigoku Guruma: forward/backward + 2punches
If nearby opponent, Ken will grab him and pull him along forming a wheel which gains momentum and finally releasing the opponent to be flung into the air.

Inazuma Kakato Geki: forward/backward + 2kicks (kkk rapidly)
Ken will grap his opponent and do a series of quick kneejabs followed by a high raising kick which sends the opponent flying.

Jigoku Fuusha: forward/backward + 2punches in air
If nearby opponent, Ken will grab the opponent and spiral like a windmill, building up momentum and releasing him.

Jigoku Geki: forward/backward + 2 kicks in air
Ken grabs his opponent, swings over his opponent and does a backbreaking knee jab upon landing.

Hadouken: qcf + punch
Ken gathers his internal energy and fires a ball of fire which flys across the screen.
LP does travels slowly and does one hit, MP travels faster and does two, HP goes even faster and does three.
Heavier versions will "eat" other forms of projectiles.

Zankuu Hadouken: qcf + punch (In air)
Ken gathers his chi mid air and thrusts it at a 45% angle! Heavier versions do more hits but have recoil effect and will "eat" other forms of projectiles.

Bakuretsuken: qcb + punch (In air)
Ken forms unstable flaming energy in his hands and thrusts it out, causing an exploding vacuum of flame.

Fujin Senkyaku: DP + kick (Heavy kick extension: kick, kick)
Strength of kick determines type of attack.
Heavy kick version can be extended by pressing kick again.

Tatsumaki Senpuu Kyaku : qcb + kick (can be done in air)
Ken twirl's his body at lethal speed as he extends his leg outward to hit multiple times.
kick strength determines distance moved, hits induced and damage induced.
Perfect for air combos.

Tenshou Tatsumaki Senpuu Kyaku : qcf + kick
Ken rises as he does a hurricane kick, finishing off the move with a slammy kick which slams the
victim into the ground.
Great to start OTG's with.

Shoryuken : dp + punch
Ken brings his fist up and flys upwards into the air.
Ken's basic anti air attack.

Seoi Shoryuken: dp + punch (During or after dragon punch)
Ken brings his other fist up into the air for a second dragon punch.
Ken's basic follow up for the dragon punch.

Ryuujin Kyaku: qcf + kick
Ken will dive kick downward. Lk goes straight through, mk makes ken rebound after contact and hk allows ken to slip in a quick attack after a flaming dive.

Makuu Shihai : dp + 2 punches/kicks or rdp + 2 punches/kicks
Ken moves behind a parallel framespan.
DP makes ken warp forward, RDP makes ken warp backward. Punches makes him travel further than kicks.
A very useful move for crossups...

Zenpu Tenshin: qcb + punch
Ken rolls like a wild tire.
Can go through any attack.

Shinpou Ryu: Medium Punch + Medium Kick
Ken gathers energy from his surroundings at an accelerated rate.



------------------------------------->
Super Moves:

One Bar Super combos:

Shoryureppa: qcf, qcf punch (ppp rapidly!) *MSSM Possible*
-This move can be mashed-
Ken does two small advancing dragon punches, then does a final flaming dragon punch which sends the opponent flying!
Easy to combo into and out off. If mashed at the last part, Ken's flames will hit the opponent more times for extra damage!

Shinryuken: qcf, qcf + kick (kkk rapidly!) *MSSM Possible*
-This move can be mashed-
Ken encompasses the power of the dragon as his Evil Intent combines with his flame. With a great explosion, Ken does a spiralling dragon punch! This move can be mashed for more hits and extra damage!

Shippu Jinrai Kyaku: qcb, qcb + kick (kkk rapidly!) *MSSM Possible*
Ken starts a kicking frenzy, and ends with a rising swipe kick. If the kick connects, then Ken will explode and do a super rising hurricane kick.

Messatsu Shakunetsu Hadou: qcb, qcb + punch*MSSM Possible*
Ken gathers his internal energy and compresses it, thrusting it out for a great 9 hits.
This move will literally destroy anything in its way.

Tameiki Wari: d, d, d + kick *MSSM Possible*
Ken goes from  forward stance and slams his left foot on the ground, creating an immense shockwave on the ground which sends the opponent flying upward!
Excellent to start an OTG combo!
Opponent must jump or block low to avoid shockwave.

Shakunetsu Hadou Ken : hcf + 2kicks *MSSM Possible*
Ken swings his arm forward at incredible speed with the help of his flaming Ki charge, if his charging fist meets the opponent, Ken will burst his Ki out in one single blast at the enemy. This move can be mashed for more chip if opponent blocks.

Kuuchuu Shakunetsu Hadou Ken : qcb, qcb + 2kicks *MSSM Possible*
Ken swings his arm forward at incredible speed with the help of his flaming Ki charge, if his charging fist meets the opponent, Ken will burst his Ki out in one single blast at the enemy. This move can be mashed for more chip if opponent blocks.

Garyuu Messhuu: qcf, qcf + kick (kick rapidly!) (In Air) *MSSM Possible*
Ken gathers his energy and does a super dive kick upon landing he will do two rising dragon punches.

Tenma Gou Zankuu: qcf, qcf + punch (In Air) *MSSM Possible*
Ken concentrates his chi into a ball and unleashes it at his opponent at great speed in mid air! 

Tenrai Bakuretsuzo: qcb, qcb + punch (In air) *MSSM Possible*
Ken sets up an unstable ball of energy which combusts before him, sending his opponent flying away!

Skuhachi: d, d, d + punch *MSSM Possible*
Ken's ultimate move! Moving at light speed, Ken charges past his opponent, rendering him incapacitated for a surge of scorching heat which follow behind Ken!


Two bar super combos:

Kyouja Renbu: qcf, hcb + punch *CVS2 Special Cancelling Possible!*
Arguably the coolest super in the game! (:p) 
Ken Bursts into a kicking frenzy, then goes into a rushing gut punch, hop kick and earthshake stomp! If the hop kick connects, He do a earthshake stomp as he summons all his evil intent into one single Dragon Punch!
The earthshake and Shun Goku Shoryuken cannot be blocked.
The earthshake can be escaped out of by jumping.
The Shun Goku Shoryuken can be escaped out of by getting behind Ken.

Shouki Hatsudou - MEGA END: hcf + 2punches (kkk rapidly!)
-This move can be mashed-
Ken will charge forward with his fist at the enemy and will attempt to juggle his victim with a few standing punches. If His uppercut connects, Ken will burst upward with a dragon punch, hitting his opponent up into the sky where he then slams him down into the earth. Ken will then charge up and unleash a descending hadouken at his opponent. 
If mashed sufficiently, ken will stomp on his downed opponent.

Three bar super combos:

Shun Goku Satsu: lp, lp, f, lk, hp
Ken becomes overcome by the wave of killing urge and warps forward. If he manages to grab the opponent, he loses all control over himself
and the screen fades out. A series of murderous hits takes place but ken manages to regain composure. The victim is left lying on 
the floor as ken trys to get a hold of himself.
Ken has an alternate ending for this move which happens with a 50% probability

Special Modes:

CVS 2 Custom Combo Mode: (Requires three levels) (Can be done in air): Heavy punch + Heavy Kick
CVS2's custom combo mode... nuff said :p


--------------------------->
Tips and Tricks:

Taunt! Ken's defense increases after his taunt so slip one in every round to keep the upper hand.

Mash whenever possible! Mash his Shoryureppa, his shinryuken, his shippu jinrai kyaku, mega end, and his kick throw for more damage and more hits!

Ken's hadouken is mainly used to get closer to the opponent. Try throwing a slow hadouken then ashura warping forward to get behind the opponent.

Super cancel! You never know when your next chance to combo the opponent into a super combo will be, so when you do hit succesfully, try to burn all your levels.

Stay out of corners! Corners are any player's worse enemy. Use Ken's Hadouken/Ashura warp crossup to get you out.

Don't stay defensive! Use Ken's alpha counter's turn the tables! Back to down motion and attack will use up one level of your super bar. Counter with punch does an invulnerable dragon punch, counter with kick does a quick thrust kick.

Keep getting hit out of a super move? Throw a hadouken out right before you do the super move. The hadouken will keep going even throughout the super pause so you can catch the opponent off guard!

Don't leave your opponent alone when downed, dash in and OTG them!

Recover! Do not let yourself be juggled mercilessly by your foes, make use of the air/ground recovers whenever possible.

Want to learn new combos? Watch Evil Ken's AI in action!


------------------------>

Credits: *crosses fingers, please don't let me forget anyone*

Richard Vale, AKA King Tigre: For working with me on Evil Ken and being a great friend and idea generator. For the new portrait and top notch sprite edits.

Tenshin: For creating the ultimate ken in terms of gameplay for me to base Evil Ken on. Without his talent and devotion, Evil Ken would not have the superb gameplay feel that he has now.

The Dreamslayer: For adding some much needed new life to Evil Ken with his sprite edits :)

Necromancer and his page of coding, the Abyss! For the power up code and the time slowdown code, and for showing me that coding can be fun!

Mattasaur: For his ideas and input, for the perfect coding technique to mainpulate a dissapearing effect, the KOF200 sprites and for keeping MUGEN fun with his wacky screenshots page on the Riot of the blood rehabilitation center!

Frenchi Guy: For ripping those beautiful explosion and dragon sprites for Lee Recca which I used.

Kenshin: For giving me advice on programming and for showing me how cool edits can be with his Hien, which I studied to create his AI.

MHZ: For Dan's sprites which I used in the Dan murder intro.

MMR and Big Eli: For some M.Bison sprites.

Baby Bonnie Hood: For developing the kickass Baby Bonnie Hood which I studied to create Evil Ken's AI. BBH kicks Muchos Anus! :p Also for the many bug reports and suggestions.

K_Kusanag: For help with exps, coding, and for all the hard work infinite and bug testing!

Fou-Lu: For bug testing and infinite testing.

Rabite: For all the bug reports and suggestions :)

Kamek: For permission to use that beautiful mvc2 super charge sample!

Orochi Herman: For permission to use those hitsounds, and for the idea of KO effects.

009's creator: For the cool tornado effects as well as his 009 which I studied to improve Evil Ken's Visual effects.

NeoGouki: For more help with exps :D

Sunboy: For psylocke who I studied to make Evil Ken's projectiles cancellable.

Tenebrous, for the special intros code which I built on.

Setsuna X: For cleaning Evil Ken's teeth for the get hit animations as the idea of the heavy breathing pose.

FallenAngel: For the tutorial website! (Whew!)

VariantX: For bug testing the CVS2 CC mode system.

Squall_L: For the idea of a decreasing constant palfx code.

GoTeNkZ: For the CVS2 super cancelling idea

Hayama's website for the base of evil ken's voice and some sound effects.

Everyone at #Mugen!! K3nshin, [E], Kyo_Kusanag, Fou_Lu, Mattasaur, Warptigon, O_Herman, Mizuki, KingTigre, Koga, mugen420, DrkIntent, Sykotik, Cabbit, Alpha4, and last but not least, Sunboy  for friendship and feedback.

Napster, for some voice samples and sound effects from capcom vs snk.

Cool edit pro, what would I do without this miracle? ;p

Mizuki Takase: For helping me out with some coding! Thanks, Teach!

Mictlantecuhtli: For Evil Ken's temporary portrait.

Tenebrous and VK for gouki's footstomp animation and reference to the raging demon code and ashura warp codes.

RyuV's creator, JeremyLee, from which I learnt how to manipulate the envshake code and background effects codes.

Daimon plus' creator, wongmugen, for showing me how cool earthquakes could affect the game.

KaoMegura: For all the excellent faqs and names of moves from the shotos.

Ayu Tukimiya's Mugen developer, Arche for the sparks, charge sprites and some hits sprites.

James Chen: For the awesome gameplay faqs which I studied to emulate certain systems Evil Ken uses.

All the people at the Mugen Development forum who showed great interest in Evil ken and kept me and Kingtigre working in him!

Everyone who mailed me and kept me and Kingtigre going on the project.

Everyone who surported Tenshin.

All the creators who developed characters for MUGEN and made it so fun!

Capcom: For all the kickass games! And from the  street fighter universe where Ken is from.

Singapore Street Fighter Comix: For the idea of Evil Ken.

Made in Singapore!

Ciaoz! Send feedback to reuy@email.com
Come Visit us at the Mugen Institute!
*Mugen Institute -=> http://www.areyouingenious.com/mugen/*
*The Muresame -=> http://reu.0catch.com*

Coding is fun! If Reu can code, so can you!






Archived Updates:


----------------------------------->
What's new since Beta 3?

Bigger and better readme.txt!
Super jump from Capcom vs SNK
Tweaked shoryureppa.
Improved super cancelling! Let the cancelling begin!
Changed evil ken's shin hadouken charge sprite.
Tweaked all special moves and added a new special move! The Rising Hurricane kick!
Raging Demon will not kill.
Hurricane kick make opponent fall now for easier comboability.
All Earthstomps must be jumped out of to avoid being hit. You can't block the GROUND, right? :p
Ken's rave's Shun Goku Shoryuken will connect as long as opponent is infront of ken.
COMBO MADNESS!!! Evil Ken's ability to chain standing and crouching attacks has been improved,
he also can OTG combo! Which means... looonglooong combos!
6 improved palletes!
Added a couple of new sound effects, as well as optimized the sound file - Make sure you download the updated sound file!

----------------------------------->
What's new since Version 1.0?

Tweaked rising hurricane kick. Implemented the accurate angles of accension whilst rising.
Gave Shinryuken and Shoryureppa ability to hit opponent while in lying state.
Tweaked crouching lightkick down.velocity. I noticed that some characters cannot be OTG'd simply because their down hit up frames are missing clsn2 boxes.
Temporary portrait. Yeah I know it sux, better then nothing, right? :p
Reassigned teleport and raging demon move frames. Ken looks like he's experiencing wind now.
Tweaked the hell out of his shinryuken, redid his Shoryureppa and made his Shippu Jinrai Kyaku Hurricane vertical hit more.
Did some more damage moderation, sorry guys.
2 New palletes thanks to Richard Vale! Grey and Shiny red!
Redid Rising hurricane kick. Noe ken will only do a slammy kick if the move connects.

------------------------------------->
What's new since Version 1.1?
Added tonnes of new voice sounds!
Corrected some sound placements here and there.
Made the Shinryuken and last part of the shoryureppa mashable! Mash away!
Tweaked the hurricane kick.
Damage moderation again.
Finally got a decent portrait! Thanks to Mictlantecuhtli for the portrait!
Implemented cool wind effects, thanks to King Tigre!

-------------------------------------->
What's new since version 1.2?
Fixed wind effects axis!
New Portrait based on Mic's done by KingTigre!
Fixed mini portrait. No more pallete problems!
Implemented ground effects for earthshake and earthstomps!
Implemented bigger sparks for super moves!
Added New random Intro and new random win pose!
Redid Earthshake stomp. Can now be comboed into easier!
Fixed collision boxes for Ken's taunt and Earthshake stomp!
Fixed flame bug when cancelling from fierce shoryuken to or Super cancelling from Shoryureppa.
Fixed bug in Raging demon which made the screen fade out too early.
Fixed Shinryuken so opponent won't look like he's in a spasm when getting hit.
Fixed sprites so ken's teeth will not be the same color as his eyes.
Fixed shoryureppa down hit velocity so it can be comboed into easier.
Gave ken the ability to charge up. Redid charge sparks thrice to be like CVS.
Gave ken 6 new palletes. Featuring Evil Ryu's skin color from CvS, hold start and select to activate.
Implemented new super effects, wind effects, ground stomp effects from EFZ.
Added special Intros against Ryu, Akuma and Sakura! thanks to tenebrous' special intros code.
* Redid Ken's Rave and Raging Demon
* Gave Ken a new super como move: Rage Burst! Thanks to Necromancer's slow down code!
Added a Special Power mode when fighting against Ryu or Akuma

(New from Test Run release)
* Tweaked Rage Burst move. Included Sorrowedge's Haste code. Also decreased damage done whilst in Rage.(Thanks again, Necromancer!)
* Fixed shadows during Ken's Rave.
Gave ken more comboability (WTF? MORE?!):
All heavy attacks can now be cancelled into special/super moves
Ken can do a vs style jump or CvS style jump for his Air combos... this may take a little getting used to but the combos can be varied more.
Big Portrait now Shows pallete changes! Major props to King Tigre! :)
*Gave Rage Burst a custom combo feel. FIREBALL MADNESS!!!!*
All known infinites will now only work in Rage Burst Mode
Gave rage burst afterimage effects as well as standing KI flowing effects.
*Totally redid all the special intros!
* (To all developers who's character's portrait I used for the special intros, if you wish me to remove them just give me the word. ) *
Fixed charge up effects.
Redid Raging Demon ending. 
Fixed hadoukens so you can't infinite juggle unless in rage mode.
Fixed afterimages.
Fixed spark sizes for raging demon and Shun Goku Shoryuken.
Got rid of a couple of infinite and quasi-infinite combos.
Added more air combobility.
Evil Ken can now interswitch chain combos while crouching and standing.
Yesterday, Akuma and Evil ken had a hop kick competition, now Evil ken has perfected his hop kick and perform it as an additional move. Also gave evil ken back his short slammy kick.
Added the Additional moves section in the readme.
Added 1 new intro, 2 new winposes, thanks to King Tigre who made the sprites!

----------------------------------->
What's new since Version 2 Pro?:

Ken can now chain from a jumping fierce or roundhouse to air hurricane kick.
Reassigned rising hurricane kick to QCF and kick.
Completely Redid Ken's Shinryuken!
Added flaming finish to Raging demon.
Added nokill settting to last 3 hits of Ken's Rave, as well as adding more hit pause time so likelyhood to escape is minimized.
Added a new move during Rage Burst: Eye of the Hurricane
Removed the combos section and added a tips and tricks section.
Took out slowdown effect from rage mode.
Added some "Basic" AI. (Thanks to Kenshin's Hien and Baby Bonnie Hood's BBH which I used for reference).
Made super moves cancellable from Ashura warp.

------------------------------------------------>
What's new since Version 3?
  
Character Issues:
 After days of gruelling study of the gibberish dictionary, Evil Ken has learnt lots of new gibberish!
 Made air Hurricane Kick able to combo as moving backwards (As demonstrated by AI)
 Added 4 New Super Moves! Kuuchuu Shin Hadouken, Buster Wolf, Kuuchuu Buster Wolf and MEGA END!
 Redid SHin Hadouken spark animation.
 Implemented KingTigre's new Evil Ken Portrait!
 Implemented new voice effects to most super moves.
 Fixed Deux's "Evil Flyer" Bug. 
 Removed Special intro against sakura, redid Baby Bonnie Hood's and added in Ryu and Akuma's.

Technical stuff:
 Made shinryuken effects removeongethit.
 Cannot super cancel from a super move to the same super move anymore.
 Redid juggle points system.
 Fixed Shin Hadouken spark axis.
 Shrank power mode wind animations.

AI Issues:
  AI will not recover when he's not supposed to (no canrecover flag).
  AI has 3 air combos: Advancing, Stationary X and Reversing.
  Made AI foul up ground combos more often.
  AI will now start combos when opponent is near the ground.
  AI will OTG into combos more often.
  AI will now dragon punch more often instead of poke jabs when opponent is in the air
  AI will now air throw when the situation presents itself.
  AI will not cancel into super moves from ashura warp unless player is hit first.
  AI will not throw 2 Shin Hadouken's in a row.
  Greatly extended all combo trees.
  Tweaked combo trees to perfection. 

------------------------=======================>
What's new since version 4?

Bug Fixes:
 Fixed Special Intro with self bug.
 Fixed idle intros and endings bug.
 Fixed one occurence of the throw bug.
 Fixed command ticks for rage burst and earthshake stomp.
 Fixed "VK" infinite for good.
 Fixed air super landing bugs.
 Fixed forward dash bug.

Technical issues:
 Made it easier to super cancel from shin hadouken and kuuchuu shin hadouken.
 Tweaked visual effects of Shinryuken.
 Tweaked AI.

Player issues:
 Added new move, shoryuken extra.
 Added a new intro.
 Replaced Evil Ken charging sprites with KingTigre's nicely done edits.
 Added new damage reduction system thanks to Ragnarok Nemo and Kamek.
 Tweaked special intros to cinematic perfection with the help of Mattasaur.
 Added ken sprites now look different to evil ken sprites thanks to Kingtigre!
 Replaced face grab winpose with a new winpose.
 Greatly increased comboability in rage burst mode.
 Taunt has effect. Taunt will now increase defense.
 Added Dive kicks and super dive kick.
 Rage burst can be done in air.
 Renamed looottttts of moves.

--- Gave up updating the What's new section D'oh!






------------------------=======================>
What's new since version 5?

Bug Fixes:
 TONNES of bug fixes

Technical issues:
 Tweaked AI
 Tweaked pausetimes
 Fixed super charge anim pallete problem.

Player issues:
 Redid hadoukens and shinkuu hadoukens!
 Added new KO effects!
 Added new super cancel effects!! Thanks to Kamek for the Mvc2 sample!
 Changed hitsounds thanks to Orochi Herman!
 Added 2 new kick specials
 Added CVS roll
 Optimized sff and snd size
 Revised Shinkuu Hadouken and Ken's Rave movement
 *Implemented the Meta Super Special Moves* (Read below to find out more)
 Balanced out gameplay
 Tweaked Ken's Rave
 Redid Raging Demon
 Added all MSSMs for all level one super moves.



What's new in the patch update?
Fixed a critical animation bug in MSSM ground hado buster.
Tweaked hadoukens.
Killed launch infinite
Tweaked standing ground attack guard velocities.


------------------------=======================>
What's new since version 7.1?

Assigned short roll to lp+lk

Made f+mk and b+mk only blockable high

Fixed losing winpose

Fixed powergain to Tenrai Bakuretsuzo super moves

Made kneeing throw mashable out of

Tweaked AI hiccups

Added crouch to getup frame

Tweaked dashes to prevent air super glitch

Lessened Skuhachi block damage

Redid Mega end ending fireball

Redid AI trigger, thanks to the Necromancer and Kaku Kuo :)

Added opponent burning effects.
 
------------------------=======================>
What's new since version 6?
Altered Mini Portrait to match our Upcoming Evil Ryu ;)
Tonnes of tweaks in supers.
Shippu Jinrai Kyaku normal and MSSM accelerate during hurricane kick part.
Rendered MSSM Tameiki Wari dragon to be a real projectile.
Added better effects for Hadou Busters.
Altered AI, more defensive against extra offensive AIs, less vulnerable against turtlers.
Altered Evil Ken' s expressions and made his eyes glow during stance.
Added a few new intros
Added new effects to all fires!
Redid Fireball codings!
Redid Alpha counters and added Air alpha counters, thanks to Mattasaur for those KOF2000 counter sparks!
Redid Charge up effects
Added flame effect to roundhouse dive kick and super dive kick variations.
Tweaked throws and added new kick air throw.
Evil Ken can now grab his opponent for an aerial throw if any aerial normal attack hits opponent.
*ADDED ZANKUU HADOUKEN, TENMA GOU HADOUKEN AND MSSM TENRAI GOU HADOUKEN!*
*ADDED BAKURETSUKEN, TENRAI BAKURETSUZO, MSSM SHAKUNETSU BAKUTETSUKEN NOW INCLUDED*
*ADDED SKUHACHI SUPER ART AND NEW WINPOSE*
Tweaked throws and added new kick air throw.

Added vulnerabilities:
Added short recovery time after ashura warp

What to expect in the next release?
Lots of stuff with our upcoming Evil Ryu

------------------------=======================>
What's new since version 7.33?
Fixed lots of bugs, thanks to Baby Bonnie Hood ;)
Made projectiles cancellable!!! XD

Fixed projectile spawning bug

------------------------=======================>
What's new since version 7.24?
Various balancing issues like recovery time and damge mufflers have been tweaked.
Added CVS2 CC mode and Super cancelling for Ken's Rave.
Changed guard cancels to require 1 level now.